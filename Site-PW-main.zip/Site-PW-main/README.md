# Site-PW
Site da empresa Aesthetic Games, projeto da disciplina de PW

#Site explicando e dando exemplos de commits semânticos
https://github.com/iuricode/padroes-de-commits

#Instruções para os comandos do GitHub no prompt
-Copie o link do repositório primeiro-
1- git clone <link do repositório> (clona o repositório no Git para um local)
2- cd Site-PW (entra na pasta do repositório)
3- code . (abre o visual code para programar)

-Depois de programar-
4- git status (verifica quais foram as mudanças que voçê fez)
5- git add <arquivou> ou <pasta> (adicione o que você modificou)
6- git commit -m "Escreva aqui o que você atualizou" (VAMOS UTILIZAR COMMITS SEMÂNTICOs PORFAVOR)
7- git push (coloca as modificações no repositório do Git)

-Para excluir um arquivo ou pasta-
git rm -r <arquivo> ou <pasta>

Caso o seu repositório local esteja desatualizado o comando para resolver isso é:
git pull
